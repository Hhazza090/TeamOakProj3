import json
import pymysql


hostname = "sjinaongkan-test.cluster-ctmkzdmsuggv.us-east-1.rds.amazonaws.com"
user = "admin"
password = "nack0320"
db = "sjinaongkan-test"

conn = pymysql.connect(host=hostname, user=user, passwd=password, db=db, connect_timeout=60)

def lambda_handler(event, context):
    req_body = json.loads(event["body"])
    
    name = req_body["name"]
    email = req_body["email"]
    location = req_body["location"]
    option = req_body["options"]
    experience = req_body["experience"]
    education = req_body["education"]
    phone = req_body["phone"]
    resume = req_body["resume"]
    
    with conn.cursor() as cur:
        try:
            query = "INSERT INTO your_table (name, email, location, option, experience, education, phone, resume) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            cur.execute(query, (name, email, location, option, experience, education, phone, resume))
            conn.commit()
        except Exception as e:
            print(e)
    
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Credentials': 'true',
            'Content-Type': 'application/json'
        },
        'body': json.dumps({"message": "Data inserted successfully."})
    }
